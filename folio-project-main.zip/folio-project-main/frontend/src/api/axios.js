// frontend/src/api/axios.js
import axios from 'axios';

const instance = axios.create({
  baseURL: '/api', // Use relative URL for both local and production
});

// This interceptor runs before EVERY request.
// It reads the token from localStorage and adds it to the Authorization header.
instance.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export default instance;